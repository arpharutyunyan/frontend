$('.owl-Carousel').owlCarousel({
    loop: true,
    center: true,
    items: 3,
    nav: true,
    responsiveClass: true,
});
